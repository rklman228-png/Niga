from PIL import Image, ImageDraw

# Hand-pixelled 16 px strip: no emoji silhouettes and no antialiasing.
S = 16
sheet = Image.new("RGBA", (S * 8, S), (0, 0, 0, 0))

INK = (25, 29, 33, 255)
INK_LITE = (57, 63, 68, 255)
WHITE = (238, 242, 235, 255)
SILVER = (173, 193, 194, 255)
DIAMOND = (54, 211, 204, 255)
DIAMOND_LITE = (151, 255, 237, 255)
GOLD = (247, 184, 49, 255)
GOLD_LITE = (255, 229, 112, 255)
WOOD = (145, 82, 36, 255)
WOOD_LITE = (202, 130, 57, 255)
LEATHER = (126, 68, 43, 255)
RED = (205, 54, 50, 255)
PURPLE = (151, 88, 196, 255)
GREEN = (58, 159, 81, 255)
SKIN = (213, 154, 106, 255)


def icon(index):
    return ImageDraw.Draw(sheet), index * S


def px(draw, ox, points, color):
    for x, y in points:
        draw.point((ox + x, y), fill=color)


# 1 — Challenges: crossed diamond sword and iron axe.
d, o = icon(0)
for x, y in [(2, 1), (3, 2), (4, 3), (5, 4), (6, 5), (7, 6), (8, 7), (9, 8), (10, 9)]:
    d.rectangle((o + x, y, o + x + 1, y + 1), fill=INK)
px(d, o, [(2, 1), (3, 2), (4, 3), (5, 4), (6, 5), (7, 6), (8, 7)], DIAMOND_LITE)
px(d, o, [(3, 1), (4, 2), (5, 3), (6, 4), (7, 5), (8, 6)], DIAMOND)
d.rectangle((o + 8, 8, o + 12, 9), fill=INK)
d.rectangle((o + 9, 8, o + 11, 8), fill=GOLD)
d.rectangle((o + 11, 9, o + 13, 13), fill=INK)
d.rectangle((o + 12, 10, o + 12, 12), fill=WOOD_LITE)
for x, y in [(13, 1), (12, 2), (11, 3), (10, 4), (9, 5), (8, 6), (7, 7), (6, 8), (5, 9)]:
    d.rectangle((o + x - 1, y, o + x, y + 1), fill=INK)
px(d, o, [(13, 1), (12, 2), (11, 3), (10, 4), (9, 5), (8, 6), (7, 7)], SILVER)
d.rectangle((o + 2, 9, o + 6, 10), fill=INK)
d.rectangle((o + 3, 9, o + 5, 9), fill=GOLD)
d.rectangle((o + 1, 10, o + 4, 14), fill=INK)
d.rectangle((o + 2, 11, o + 3, 13), fill=WOOD_LITE)

# 2 — Expeditions: vanilla-like compass.
d, o = icon(1)
d.rectangle((o + 4, 1, o + 11, 14), fill=INK)
d.rectangle((o + 1, 4, o + 14, 11), fill=INK)
d.rectangle((o + 3, 3, o + 12, 12), fill=GOLD)
d.rectangle((o + 4, 4, o + 11, 11), fill=INK_LITE)
d.rectangle((o + 5, 5, o + 10, 10), fill=WHITE)
px(d, o, [(7, 4), (8, 4), (11, 7), (11, 8), (7, 11), (8, 11), (4, 7), (4, 8)], GOLD_LITE)
d.polygon([(o + 8, 5), (o + 9, 8), (o + 8, 8)], fill=RED)
d.polygon([(o + 7, 10), (o + 7, 7), (o + 8, 8)], fill=INK)
d.point((o + 8, 8), fill=GOLD_LITE)

# 3 — Lost items: a dropped enchanted diamond, not a grave.
d, o = icon(2)
d.polygon([(o + 8, 2), (o + 13, 6), (o + 10, 12), (o + 6, 14), (o + 2, 9), (o + 4, 4)], fill=INK)
d.polygon([(o + 8, 3), (o + 12, 6), (o + 9, 11), (o + 6, 13), (o + 3, 9), (o + 5, 5)], fill=DIAMOND)
d.polygon([(o + 5, 5), (o + 8, 3), (o + 8, 11), (o + 3, 9)], fill=DIAMOND_LITE)
px(d, o, [(1, 3), (2, 2), (13, 2), (14, 3), (14, 11), (13, 12), (3, 14)], PURPLE)
px(d, o, [(2, 3), (13, 3), (13, 11)], WHITE)

# 4 — Reward storage: shaded Minecraft chest.
d, o = icon(3)
d.rectangle((o + 1, 4, o + 14, 13), fill=INK)
d.rectangle((o + 2, 5, o + 13, 8), fill=WOOD_LITE)
d.rectangle((o + 2, 9, o + 13, 12), fill=WOOD)
d.line((o + 2, 8, o + 13, 8), fill=GOLD)
d.rectangle((o + 6, 7, o + 9, 11), fill=INK)
d.rectangle((o + 7, 8, o + 8, 10), fill=GOLD_LITE)
px(d, o, [(3, 6), (4, 6), (11, 6), (12, 6), (3, 10), (12, 10)], (235, 159, 65, 255))

# 5 — Parcels: compact parcel with a tied ribbon.
d, o = icon(4)
d.rectangle((o + 2, 3, o + 13, 13), fill=INK)
d.rectangle((o + 3, 4, o + 12, 12), fill=LEATHER)
d.rectangle((o + 4, 5, o + 11, 11), fill=(177, 104, 57, 255))
d.rectangle((o + 7, 4, o + 8, 12), fill=GOLD)
d.rectangle((o + 3, 7, o + 12, 8), fill=GOLD_LITE)
d.polygon([(o + 7, 4), (o + 4, 2), (o + 4, 5)], fill=RED)
d.polygon([(o + 8, 4), (o + 11, 2), (o + 11, 5)], fill=RED)
d.rectangle((o + 7, 4, o + 8, 5), fill=GOLD_LITE)

# 6 — Solo: one shaded player portrait.
d, o = icon(5)
d.rectangle((o + 4, 2, o + 11, 9), fill=INK)
d.rectangle((o + 5, 3, o + 10, 8), fill=SKIN)
d.rectangle((o + 5, 3, o + 10, 4), fill=(91, 53, 38, 255))
d.rectangle((o + 3, 10, o + 12, 14), fill=INK)
d.rectangle((o + 4, 11, o + 11, 14), fill=GREEN)
px(d, o, [(6, 6), (9, 6)], INK)
d.line((o + 7, 8, o + 8, 8), fill=(137, 76, 59, 255))

# 7 — Duo: two overlapping portraits.
d, o = icon(6)
d.rectangle((o + 1, 3, o + 7, 9), fill=INK)
d.rectangle((o + 2, 4, o + 6, 8), fill=SKIN)
d.rectangle((o, 10, o + 8, 14), fill=INK)
d.rectangle((o + 1, 11, o + 7, 14), fill=DIAMOND)
d.rectangle((o + 8, 2, o + 14, 8), fill=INK)
d.rectangle((o + 9, 3, o + 13, 7), fill=(196, 135, 97, 255))
d.rectangle((o + 7, 9, o + 15, 14), fill=INK)
d.rectangle((o + 8, 10, o + 14, 14), fill=PURPLE)
px(d, o, [(3, 6), (5, 6), (10, 5), (12, 5)], INK)

# 8 — World menu: clean Nether-star-like mark.
d, o = icon(7)
d.polygon([(o + 8, 1), (o + 10, 5), (o + 14, 4), (o + 11, 8), (o + 14, 12), (o + 10, 11),
           (o + 8, 15), (o + 6, 11), (o + 2, 12), (o + 5, 8), (o + 2, 4), (o + 6, 5)], fill=INK)
d.polygon([(o + 8, 2), (o + 9, 6), (o + 13, 5), (o + 10, 8), (o + 13, 11), (o + 9, 10),
           (o + 8, 14), (o + 7, 10), (o + 3, 11), (o + 6, 8), (o + 3, 5), (o + 7, 6)], fill=GOLD)
d.rectangle((o + 7, 7, o + 9, 9), fill=WHITE)
d.point((o + 8, 7), fill=GOLD_LITE)

sheet.save("resource-pack/WorldUI/assets/brigada_core/textures/font/icons.png", optimize=True)
