from pathlib import Path
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1] / "WorldUI" / "assets" / "minecraft" / "textures" / "block"
ROOT.mkdir(parents=True, exist_ok=True)


def save_texture(name: str, base: tuple[int, int, int, int], pixels: list[tuple[int, int, int, int, int, int]]) -> None:
    image = Image.new("RGBA", (16, 16), base)
    draw = ImageDraw.Draw(image)
    for x, y, width, height, color, alpha in pixels:
        shade = (color >> 16 & 255, color >> 8 & 255, color & 255, alpha)
        draw.rectangle((x, y, x + width - 1, y + height - 1), fill=shade)
    # Crisp translucent rim makes the collision plane legible without turning it opaque.
    draw.rectangle((0, 0, 15, 15), outline=(220, 252, 255, 180), width=1)
    image.save(ROOT / name, optimize=True)


save_texture(
    "gray_stained_glass.png",
    (76, 91, 103, 142),
    [
        (2, 2, 5, 3, 0x657784, 154), (9, 1, 4, 4, 0x465762, 160),
        (1, 7, 4, 5, 0x495C68, 158), (6, 6, 6, 3, 0x718692, 150),
        (11, 10, 4, 4, 0x3F505C, 164), (5, 12, 5, 3, 0x617580, 154),
        (3, 5, 2, 1, 0x9AACB5, 174), (12, 6, 2, 1, 0x9AACB5, 170),
    ],
)

save_texture(
    "brown_stained_glass.png",
    (119, 76, 42, 146),
    [
        (1, 2, 5, 3, 0x8D5B34, 158), (8, 1, 6, 4, 0x634027, 164),
        (3, 7, 4, 5, 0x70462A, 160), (8, 7, 6, 3, 0x9B663A, 154),
        (1, 12, 5, 3, 0x5B3A25, 164), (10, 11, 4, 4, 0x7D4E2D, 160),
        (3, 5, 2, 1, 0xC0874D, 178), (12, 6, 2, 1, 0xD29A59, 176),
    ],
)

save_texture(
    "lime_stained_glass.png",
    (78, 174, 74, 150),
    [
        (1, 1, 5, 4, 0x68C95E, 164), (8, 1, 6, 3, 0x3E9E49, 170),
        (3, 6, 5, 4, 0x4EB453, 164), (10, 5, 4, 5, 0x76D15D, 160),
        (1, 11, 6, 4, 0x398D43, 172), (9, 11, 5, 4, 0x5FBE50, 166),
        (4, 4, 2, 1, 0xC0ED86, 184), (12, 9, 2, 1, 0xB2E97B, 182),
    ],
)
