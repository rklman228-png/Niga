from pathlib import Path
import json
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1] / "WorldUI" / "assets" / "brigada_core"
CELL = 24
COUNT = 360
SCALE = 4
PULSE_SCALES = (0.86, 1.0, 0.93)


def base_arrow() -> Image.Image:
    canvas = Image.new("RGBA", (CELL * SCALE, CELL * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    s = SCALE
    # Textured pixel-art navigation needle: dark outline, two cyan facets and
    # a bright inlaid spine. It remains readable against snow, water and night sky.
    shadow = [(12*s, 1*s), (20*s, 14*s), (15*s, 13*s), (15*s, 20*s),
              (12*s, 23*s), (9*s, 20*s), (9*s, 13*s), (4*s, 14*s)]
    outer = [(12*s, 2*s), (19*s, 14*s), (14*s, 12*s), (14*s, 20*s),
             (12*s, 22*s), (10*s, 20*s), (10*s, 12*s), (5*s, 14*s)]
    left_facet = [(12*s, 3*s), (12*s, 18*s), (10.5*s, 20*s), (10.5*s, 11.5*s), (6*s, 13.5*s)]
    right_facet = [(12*s, 3*s), (18*s, 13.5*s), (13.5*s, 11.5*s), (13.5*s, 20*s), (12*s, 21*s)]
    draw.polygon([(x + s, y + s) for x, y in shadow], fill=(1, 10, 17, 175))
    draw.polygon(shadow, fill=(3, 20, 29, 255))
    draw.polygon(outer, fill=(24, 126, 149, 255))
    draw.polygon(left_facet, fill=(42, 238, 222, 255))
    draw.polygon(right_facet, fill=(42, 157, 236, 255))
    draw.polygon([(12*s, 3*s), (13*s, 10*s), (12*s, 13*s), (11*s, 10*s)],
                 fill=(232, 255, 255, 255))
    draw.rectangle((11*s, 13*s, 12*s, 18*s), fill=(171, 255, 249, 255))
    draw.rectangle((10*s, 13*s, 11*s, 14*s), fill=(255, 221, 92, 255))
    draw.rectangle((13*s, 12*s, 14*s, 13*s), fill=(255, 243, 164, 255))
    return canvas


atlas = Image.new("RGBA", (CELL * COUNT, CELL * len(PULSE_SCALES)), (0, 0, 0, 0))
arrow = base_arrow()
for frame, pulse in enumerate(PULSE_SCALES):
    for degree in range(COUNT):
        rotated = arrow.rotate(-degree, resample=Image.Resampling.BICUBIC, expand=False)
        rotated = rotated.resize((CELL, CELL), Image.Resampling.LANCZOS)
        if pulse != 1.0:
            size = max(1, round(CELL * pulse))
            scaled = rotated.resize((size, size), Image.Resampling.LANCZOS)
            rotated = Image.new("RGBA", (CELL, CELL), (0, 0, 0, 0))
            rotated.alpha_composite(scaled, ((CELL - size) // 2, (CELL - size) // 2))
        # Keep every glyph's advance identical even when the rotated silhouette is narrow.
        rotated.putpixel((0, CELL - 1), (0, 0, 0, 1))
        rotated.putpixel((CELL - 1, CELL - 1), (0, 0, 0, 1))
        atlas.alpha_composite(rotated, (degree * CELL, frame * CELL))

texture = ROOT / "textures" / "font" / "navigation_360.png"
texture.parent.mkdir(parents=True, exist_ok=True)
atlas.save(texture, optimize=True)

font = {
    "providers": [{
        "type": "bitmap",
        "file": "brigada_core:font/navigation_360.png",
        "ascent": 17,
        "height": 20,
        "chars": [
            "".join(chr(0xE100 + frame * COUNT + value) for value in range(COUNT))
            for frame in range(len(PULSE_SCALES))
        ],
    }]
}
font_path = ROOT / "font" / "navigation.json"
font_path.parent.mkdir(parents=True, exist_ok=True)
font_path.write_text(json.dumps(font, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
