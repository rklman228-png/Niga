# World UI resource pack

Resource-pack format `117.0`, made specifically for Minecraft `26.3 Snapshot 9`.

Build from repository root:

```bash
base64 -d resource-pack/WorldUI/pack.png.b64 > resource-pack/WorldUI/pack.png
python3 resource-pack/tools/make_icons.py
cd resource-pack/WorldUI
zip -r ../world-ui-26.3-snapshot-9.zip .
```
